Développement d'un modèle de prédiction de prix pour les biens dans l'agglomération de Tours.

1. Aspiration des données, génération .json
2. Transformation des données, génération csv
3. Nettoyage données, génération numpy
4. Entrainements modèles
5. Génération d'un résumé : bonnes affaires?
6. Justification des choix dans notebooks
