# A FAIRE

- Regarder pandas.pop pour enlever des colonnes.
- Reprendre le notebook de nettoyage via scikit learn, utilisation de ColumnTransformer.
- Ajouter un notebook pour la partie Machine Learning.
- Distinguer les justifications (story-telling) via les notebooks, de la production via les
  scripts py.
- Modifier le motif pour la détection de quartier dans les liens et regarder les modifications.
- Réécrire transformation en POO?
- Gérer le problème de la fuite de mémoire de geckodriver (relancer périodiquement?)
- Améliorer la détection du quartier.
